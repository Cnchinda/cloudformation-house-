const handler = (event) => {
  console.log('Lambda One!');
}

module.exports = {
  handler
}