const handler = (event) => {
  console.log('Lambda Two!');
}

module.exports = {
  handler
}